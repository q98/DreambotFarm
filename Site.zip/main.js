document.addEventListener('DOMContentLoaded', function() {
    // Clock In
    const clockInForm = document.getElementById('clockInForm');
    if (clockInForm) {
        clockInForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const startMileage = document.getElementById('startMileage').value;
            const shiftData = {
                startMileage: startMileage,
                deliveries: [],
                cashTotal: 0,
                creditTotal: 0,
                cashIn: 0,
                clockInTime: new Date().toISOString(),
            };
            localStorage.setItem('currentShift', JSON.stringify(shiftData));
            window.location.href = 'shift.html';
        });
    }

    // Redirect to index.html if no shift is active
    if (window.location.pathname.endsWith('shift.html')) {
        const currentShift = JSON.parse(localStorage.getItem('currentShift'));
        if (!currentShift) {
            window.location.href = 'index.html';
        } else {
            updateShiftOverview(currentShift);

            // Add Delivery
            const deliveryForm = document.getElementById('deliveryForm');
            deliveryForm.addEventListener('submit', function(event) {
                event.preventDefault();
                const deliveryType = document.getElementById('deliveryType').value;
                const deliveryAmount = parseFloat(document.getElementById('deliveryAmount').value) || 0;
                if (deliveryType === 'cash') {
                    currentShift.cashTotal += deliveryAmount;
                } else {
                    currentShift.creditTotal += deliveryAmount;
                }
                currentShift.deliveries.push({ type: deliveryType, amount: deliveryAmount, time: new Date().toISOString() });
                localStorage.setItem('currentShift', JSON.stringify(currentShift));
                updateShiftOverview(currentShift);
            });

            // Clock Out
            const clockOutButton = document.getElementById('clockOutButton');
            clockOutButton.addEventListener('click', function() {
                const endMileage = prompt("Enter the ending mileage:");
                const cashIn = parseFloat(prompt("Enter the total cash accepted today:")) || 0;
                if (endMileage) {
                    currentShift.endMileage = endMileage;
                    currentShift.cashIn = cashIn;
                    currentShift.clockOutTime = new Date().toISOString();
                    saveShiftData(currentShift);
                    localStorage.removeItem('currentShift');
                    window.location.href = 'index.html';
                }
            });
        }
    }

    // Search Shifts
    const searchForm = document.getElementById('searchForm');
    if (searchForm) {
        searchForm.addEventListener('submit', function(event) {
            event.preventDefault();
            const searchDate = document.getElementById('searchDate').value;
            displayShiftData(searchDate);
        });
    }

    // Show Weekly Overview on Index Page
    if (window.location.pathname.endsWith('index.html')) {
        const currentWeek = getCurrentWeekString();
        console.log("Current week string:", currentWeek);
        const weeklyData = fetchWeekData(currentWeek);
        console.log("Weekly data fetched:", weeklyData);
        renderWeeklySummary(weeklyData, 'currentWeekGraph');
    }
});

function updateShiftOverview(shift) {
    const hourlyPay = 12;
    const hoursWorked = calculateHoursWorked(shift.clockInTime, shift.clockOutTime || new Date().toISOString());
    const totalPay = hoursWorked * hourlyPay;
    const x = (shift.cashTotal - shift.creditTotal - totalPay);
    const profit = (shift.cashIn - x);

    const shiftOverview = document.getElementById('shiftOverview');
    shiftOverview.innerHTML = `
        <p>Start Mileage: ${shift.startMileage}</p>
        <p>Clock In Time: ${shift.clockInTime}</p>
        <h3>Deliveries:</h3>
        <ul>${shift.deliveries.map((delivery, index) => `<li>${delivery.type}: $${parseFloat(delivery.amount).toFixed(2)} at ${new Date(delivery.time).toLocaleTimeString()} <button onclick="removeDelivery(${index})" class="btn btn-danger btn-sm">Remove</button></li>`).join('')}</ul>
        <p>Total Cash: $${shift.cashTotal.toFixed(2)}</p>
        <p>Total Credit Tips: $${shift.creditTotal.toFixed(2)}</p>
        <p>Total Cash Accepted: $${shift.cashIn.toFixed(2)}</p>
        <p>Total Hours Worked: ${hoursWorked.toFixed(2)}</p>
        <p>Total Pay: $${totalPay.toFixed(2)}</p>
        <p>Profit: $${profit.toFixed(2)}</p>
        <canvas id="shiftGraph" width="400" height="200"></canvas>
    `;

    const graphData = {
        labels: shift.deliveries.map(d => new Date(d.time).toLocaleTimeString()),
        cash: shift.deliveries.filter(d => d.type === 'cash').map(d => d.amount),
        credit: shift.deliveries.filter(d => d.type === 'credit').map(d => d.amount)
    };
    renderGraph(graphData);

    if (shift.endMileage) {
        shiftOverview.innerHTML += `
            <p>End Mileage: ${shift.endMileage}</p>
            <p>Clock Out Time: ${shift.clockOutTime}</p>
        `;
    }
}

function removeDelivery(index) {
    const currentShift = JSON.parse(localStorage.getItem('currentShift'));
    if (currentShift) {
        const delivery = currentShift.deliveries.splice(index, 1)[0];
        if (delivery.type === 'cash') {
            currentShift.cashTotal -= delivery.amount;
        } else {
            currentShift.creditTotal -= delivery.amount;
        }
        localStorage.setItem('currentShift', JSON.stringify(currentShift));
        updateShiftOverview(currentShift);
    }
}

function saveShiftData(shift) {
    const weekNumber = getWeekNumber(new Date(shift.clockInTime));
    const shiftDataKey = `week_${weekNumber}`;
    let weeklyData = JSON.parse(localStorage.getItem(shiftDataKey)) || [];
    weeklyData.push(shift);
    localStorage.setItem(shiftDataKey, JSON.stringify(weeklyData));
}

function displayShiftData(dateString) {
    const date = getDateFromWeekString(dateString);
    const weekNumber = getWeekNumber(date);
    const shiftDataKey = `week_${weekNumber}`;
    const weeklyData = fetchWeekData(shiftDataKey);

    const overviewContent = document.getElementById('overviewContent');
    if (weeklyData.length === 0) {
        overviewContent.innerHTML = '<p>No shifts found for the selected week.</p>';
        return;
    }

    const days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
    const shiftsByDay = days.map(day => ({
        day,
        shifts: weeklyData.filter(shift => new Date(shift.clockInTime).getDay() === days.indexOf(day))
    }));

    const weeklySummary = calculateWeeklySummary(weeklyData);

    overviewContent.innerHTML = `
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title">Weekly Summary</h5>
                <p>Total Mileage: ${weeklySummary.totalMileage}</p>
                <p>Total Cash: $${weeklySummary.totalCash.toFixed(2)}</p>
                <p>Total Credit Tips: $${weeklySummary.totalCredit.toFixed(2)}</p>
                <p>Total Cash Accepted: $${weeklySummary.totalCashIn.toFixed(2)}</p>
                <p>Total Hours Worked: ${weeklySummary.totalHoursWorked.toFixed(2)}</p>
                <p>Total Pay: $${weeklySummary.totalPay.toFixed(2)}</p>
                <p>Total Profit: $${weeklySummary.totalProfit.toFixed(2)}</p>
                <p>Number of Deliveries: ${weeklySummary.totalDeliveries}</p>
                <canvas id="weekGraph" width="400" height="200"></canvas>
            </div>
        </div>
    `;

    renderGraphForWeek(weeklySummary, 'weekGraph');

    overviewContent.innerHTML += shiftsByDay.map(({ day, shifts }) => `
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title">${day}</h5>
                ${shifts.length ? shifts.map(shift => `
                    <div class="card mb-2">
                        <div class="card-body">
                            <p>Shift on ${new Date(shift.clockInTime).toLocaleDateString()}</p>
                            <p>Start Mileage: ${shift.startMileage}</p>
                            <p>End Mileage: ${shift.endMileage}</p>
                            <p>Clock In: ${new Date(shift.clockInTime).toLocaleTimeString()}</p>
                            <p>Clock Out: ${shift.clockOutTime ? new Date(shift.clockOutTime).toLocaleTimeString() : 'In Progress'}</p>
                            <h5>Deliveries:</h5>
                            <ul>${shift.deliveries.map(delivery => `<li>${delivery.type}: $${parseFloat(delivery.amount).toFixed(2)} at ${new Date(delivery.time).toLocaleTimeString()}</li>`).join('')}</ul>
                            <p>Total Cash: $${(shift.cashTotal || 0).toFixed(2)}</p>
                            <p>Total Credit Tips: $${(shift.creditTotal || 0).toFixed(2)}</p>
                            <p>Total Cash Accepted: $${(shift.cashIn || 0).toFixed(2)}</p>
                            <p>Total Hours Worked: ${(calculateHoursWorked(shift.clockInTime, shift.clockOutTime) || 0).toFixed(2)}</p>
                            <p>Total Pay: $${((calculateHoursWorked(shift.clockInTime, shift.clockOutTime) || 0) * 12).toFixed(2)}</p>
                            <p>Profit: $${calculateProfit(shift).toFixed(2)}</p>
                            <button onclick="editShift(${weeklyData.indexOf(shift)}, '${shiftDataKey}')" class="btn btn-primary">Edit</button>
                            <button onclick="removeShift(${weeklyData.indexOf(shift)}, '${shiftDataKey}')" class="btn btn-danger">Remove</button>
                        </div>
                    </div>
                `).join('') : '<p>No shifts found for this day.</p>'}
            </div>
        </div>
    `).join('');
}

function getDateFromWeekString(weekString) {
    const [year, week] = weekString.split('-W').map(Number);
    const firstDayOfYear = new Date(year, 0, 1);
    const daysOffset = ((week - 1) * 7) - firstDayOfYear.getDay() + 1;
    return new Date(year, 0, daysOffset);
}

function fetchWeekData(shiftDataKey) {
    return JSON.parse(localStorage.getItem(shiftDataKey)) || [];
}

function calculateWeeklySummary(weeklyData) {
    const totalMileage = weeklyData.reduce((acc, shift) => acc + (shift.endMileage - shift.startMileage), 0);
    const totalCash = weeklyData.reduce((acc, shift) => acc + shift.cashTotal, 0);
    const totalCredit = weeklyData.reduce((acc, shift) => acc + shift.creditTotal, 0);
    const totalCashIn = weeklyData.reduce((acc, shift) => acc + shift.cashIn, 0);
    const totalHoursWorked = weeklyData.reduce((acc, shift) => acc + calculateHoursWorked(shift.clockInTime, shift.clockOutTime), 0);
    const totalPay = totalHoursWorked * 12;
    const totalProfit = totalCashIn - (totalCash - totalCredit - totalPay);
    const totalDeliveries = weeklyData.reduce((acc, shift) => acc + shift.deliveries.length, 0);

    return {
        totalMileage,
        totalCash,
        totalCredit,
        totalCashIn,
        totalHoursWorked,
        totalPay,
        totalProfit,
        totalDeliveries
    };
}

function renderGraphForWeek(summary, graphId) {
    const ctx = document.getElementById(graphId).getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: ['Cash', 'Credit', 'Total Cash In', 'Total Pay', 'Profit'],
            datasets: [{
                label: 'Amount',
                data: [summary.totalCash, summary.totalCredit, summary.totalCashIn, summary.totalPay, summary.totalProfit],
                backgroundColor: ['rgba(75, 192, 192, 0.2)', 'rgba(255, 159, 64, 0.2)', 'rgba(153, 102, 255, 0.2)', 'rgba(255, 206, 86, 0.2)', 'rgba(54, 162, 235, 0.2)'],
                borderColor: ['rgba(75, 192, 192, 1)', 'rgba(255, 159, 64, 1)', 'rgba(153, 102, 255, 1)', 'rgba(255, 206, 86, 1)', 'rgba(54, 162, 235, 1)'],
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function editShift(index, shiftDataKey) {
    const weeklyData = JSON.parse(localStorage.getItem(shiftDataKey));
    const shift = weeklyData[index];
    const newStartMileage = prompt("Enter the new start mileage:", shift.startMileage);
    const newEndMileage = prompt("Enter the new end mileage:", shift.endMileage);
    if (newStartMileage !== null) {
        shift.startMileage = newStartMileage;
    }
    if (newEndMileage !== null) {
        shift.endMileage = newEndMileage;
    }
    weeklyData[index] = shift;
    localStorage.setItem(shiftDataKey, JSON.stringify(weeklyData));
    displayShiftData(shift.clockInTime);
}

function removeShift(index, shiftDataKey) {
    const weeklyData = JSON.parse(localStorage.getItem(shiftDataKey));
    weeklyData.splice(index, 1);
    localStorage.setItem(shiftDataKey, JSON.stringify(weeklyData));
    displayShiftData(shiftDataKey.split('_')[1]);
}

function clearAllData() {
    const password = prompt("Enter the password to clear all data:");
    if (password === "password") {
        localStorage.clear();
        alert("All data has been cleared.");
        window.location.reload();
    } else {
        alert("Incorrect password.");
    }
}

function calculateHoursWorked(clockInTime, clockOutTime) {
    const startTime = new Date(clockInTime);
    const endTime = new Date(clockOutTime);
    const diffMs = endTime - startTime;
    const diffHrs = diffMs / (1000 * 60 * 60);
    return diffHrs;
}

function calculateProfit(shift) {
    const hourlyPay = 12;
    const hoursWorked = calculateHoursWorked(shift.clockInTime, shift.clockOutTime);
    const totalPay = hoursWorked * hourlyPay;
    const x = shift.cashTotal - shift.creditTotal - totalPay;
    const profit = shift.cashIn - x;
    return profit;
}

function getWeekNumber(date) {
    const firstDayOfYear = new Date(date.getFullYear(), 0, 1);
    const pastDaysOfYear = (date - firstDayOfYear) / 86400000;
    const weekNumber = Math.ceil((pastDaysOfYear + firstDayOfYear.getDay() + 1) / 7);
    console.log("Calculated week number:", weekNumber); // Debugging log
    return weekNumber;
}


function renderGraph(data) {
    const ctx = document.getElementById('shiftGraph').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: data.labels,
            datasets: [{
                label: 'Cash',
                data: data.cash,
                backgroundColor: 'rgba(75, 192, 192, 0.2)',
                borderColor: 'rgba(75, 192, 192, 1)',
                borderWidth: 1
            },
            {
                label: 'Credit',
                data: data.credit,
                backgroundColor: 'rgba(255, 159, 64, 0.2)',
                borderColor: 'rgba(255, 159, 64, 1)',
                borderWidth: 1
            }]
        },
        options: {
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
}

function getCurrentWeekString() {
    const currentDate = new Date();
    const currentWeekNumber = getWeekNumber(currentDate);
    const weekString = `${currentDate.getFullYear()}-W${currentWeekNumber.toString().padStart(2, '0')}`;
    console.log("Current week string:", weekString); // Debugging log
    return weekString;
}

function renderWeeklySummary(weeklyData, graphId) {
    const summary = calculateWeeklySummary(weeklyData);
    console.log("Weekly summary:", summary); // Debugging log
    const weeklyOverview = document.getElementById('weeklyOverview');
    if (!weeklyOverview) {
        console.log("Weekly overview element not found"); // Debugging log
        return; // Ensure the element exists
    }
    weeklyOverview.innerHTML = `
        <div class="card mb-3">
            <div class="card-body">
                <h5 class="card-title">Current Week Summary</h5>
                <p>Total Mileage: ${summary.totalMileage}</p>
                <p>Total Cash: $${summary.totalCash.toFixed(2)}</p>
                <p>Total Credit Tips: $${summary.totalCredit.toFixed(2)}</p>
                <p>Total Cash Accepted: $${summary.totalCashIn.toFixed(2)}</p>
                <p>Total Hours Worked: ${summary.totalHoursWorked.toFixed(2)}</p>
                <p>Total Pay: $${summary.totalPay.toFixed(2)}</p>
                <p>Total Profit: $${summary.totalProfit.toFixed(2)}</p>
                <p>Number of Deliveries: ${summary.totalDeliveries}</p>
                <canvas id="${graphId}" width="400" height="200"></canvas>
            </div>
        </div>
    `;
    renderGraphForWeek(summary, graphId);
}
